Hi, in this project we are assigned to implement inverted index searching.
First we need to make preprocessing and indexing our words.
I used BeautifulSoup library so yuo need to install it to your working environment.
1) "pip install bs4" will install this library.
2) "python preprocessing.py" will run indexing module and create a file named "myIndex.txt" that stores indexes.
3) "python queryprocessing.py" Then you need to run this command for query processing module.
Each time you want to enter a new query, you need to run 3rd command.
When you run this command you will see "Please enter query:" text.
You need to enter your query here.
Then it will print the result to the screen.