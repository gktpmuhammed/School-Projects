We have two python file that you can run.
termproject.py file includes most of the code. It creates dictionary for from scratch knn algorithm. It includes multinomial naive bayes implementation, single and multi label knn algorthm and svm.
First you need to run termproject.py. But it will take really long time to finish.
Then you can run knn.py file.
You can change threshold and k vaues in knn.py file.