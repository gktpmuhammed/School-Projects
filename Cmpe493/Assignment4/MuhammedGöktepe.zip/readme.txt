To run my code you need to have python installed on your machine.
I am taking one filename as an argument for data file.
For example:
python assignment4.py data.txt

You need to provide filename for each run.