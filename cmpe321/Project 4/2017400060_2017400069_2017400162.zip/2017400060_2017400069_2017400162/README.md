## Command line arquements to run Halo software
To run our file:

`python src/haloSoftware.py <inputfile> <outputfile>`