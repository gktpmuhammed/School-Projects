you need to install some libraries before running my code. 

pip install matplotlib.image
pip install numpy
pip install pandas
pip install matplotlib.pyplot
pip install sklearn.manifold

after installing these libraries you need to copy the training and test set to code directory. 
Then you can run the code by 
python assignment3.py